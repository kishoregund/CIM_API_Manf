
function arrayToSubcompArray( arr, fieldName) {
	if( 'undefined' == typeof(arr) || null == arr ) {
		return arr;
	}
	var result = [];
	for( var i = 0; i < arr.length; i++ ) {
		result.push( arr[i][fieldName] );
	}
	return result;
};

function makeSelectorItemsUnique( items ) {
	"use strict";
	var sli, sel, nodes, i, iidx;
	for( i = 0; i < items.length; i++ ) {
		sli = items.slice( 0, i+1 );
		sel = arrayToSubcompArray( sli, 'entry' ).join('>');
		nodes = document.querySelectorAll( sel );
		
		if( nodes.length > 1 ) {
			iidx = Array.from(items[i].elem.parentNode.children).indexOf(items[i].elem);
			items[i].entry += ":nth-child("+(iidx+1)+")";
		}
	}
};

function getElementQuerySelector(target) {
	"use strict";
	var items = [],
	elm,
	entry, clsel;

	for ( elm = target; elm; elm = elm.parentNode ) {
		
		if( elm.hasAttribute( "id" ) ) {
			entry = "#" + elm.id;
			try {
				document.querySelectorAll( entry );
				items.push( { 'entry':entry, 'elem': elm } );
				break;
			} catch (e) {
				console.warn( "getElementQuerySelector()::e", e );
			}
		}

		entry = elm.tagName.toLowerCase();	//the tag name
		if ( entry === "html" ) {
			break;
		}
		['type', 'name'].forEach(d=>{
			if( elm.hasAttribute( d ) ) {
				var aval = elm.getAttribute( d );
				if( null != aval && "" != aval.trim() ) {
					entry += '[' + d + '="'+aval+'"]';
				}
			}
		});
		if ( elm.className ) {
			clsel = elm.className.trim();
			clsel = clsel.replace(/\:[\w-]+\b/g, '');
			clsel = clsel.replace(/[ \n\r]+/g, '.');
			entry += "." + clsel;
		}
		items.push( { 'entry':entry, 'elem': elm } );
	}
	if( 0 == items.length ) {
		return null;
	}
	items.reverse();
	makeSelectorItemsUnique( items );
	var result = arrayToSubcompArray( items, 'entry' ).join(">");
	return result;
};

