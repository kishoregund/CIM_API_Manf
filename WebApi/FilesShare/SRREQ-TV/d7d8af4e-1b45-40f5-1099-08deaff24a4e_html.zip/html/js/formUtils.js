
const FormUtils = {};



FormUtils.populateIfEmpty = function( selStr, value ) {
	alert( $(selStr).attr('id') );
	if( '' == $(selStr).val() ) {
		$(selStr).val(value);
	}
};

FormUtils.populate = function( selStr, value ) {
	var oVal = $( selStr ).val();
	$(selStr).val( value );
	return oVal != value;
};

FormUtils.getFormElementByName = function( formObj, elementName ) {
	for(var i =0; i < formObj.elements.length; i++ ) {
		if("undefined" == typeof( formObj.elements[i].name ) || null == formObj.elements[i].name || ""==formObj.elements[i].name) {
			continue;
		}
		if(formObj.elements[i].name == elementName) {
			return formObj.elements[i];
		}
	}
	return null;
};

FormUtils.titleValue = function(obj) {
	obj.title = obj.value;
};

FormUtils.checkCheckboxByValue = function( chk, val ) {
	if("undefined" == typeof(val) || null == val ) {
		return;
	}
	if( "undefined" == typeof( chk.length ) ) {
		if( chk.value == val)  {
			chk.checked = true;
		}
		return;
	}
	for( var i = 0; i < chk.length; i++ ) {
		if( chk[i].value == val ) {
			chk[i].checked = true;
		}
	}
};

FormUtils.selectOptionInSelectByValue = function(obj, val) {
	if("undefined" == typeof(val) || null == val ) {
		return;
	}
	var key;
	var i,j;
	if("number" == typeof(val.length) && "string" != typeof(val) ) {
		if(0 == val.length) {
			for(key in val) {
				for(i = 0; i < obj.options.length; i++ ) {
					if(key == obj.options[i].value) {
						obj.options[i].selected = true;
					}
				}
			}
		} else {
			for(j = 0; j < val.length; j++){
				for(i = 0; i < obj.options.length; i++ ) {
					if(val[j] == obj.options[i].value) {
						obj.options[i].selected = true;
					}
				}
			}
		}
		return;
	}
	for( i = 0; i < obj.options.length; i++ ) {
		if( val == obj.options[i].value ) {
			obj.options[i].selected = true;
			return;
		}
	}
	
};

FormUtils.selectOptionInSelectByText = function( obj, val ) {
	if("undefined" == typeof(val) || null == val ) {
		return;
	}
	var key;
	var i,j;
	if("number" == typeof(val.length) && "string" != typeof(val) ) {
		if(0 == val.length) {
			for(key in val) {
				for(i = 0; i < obj.options.length; i++ ) {
					if(key == obj.options[i].text) {
						obj.options[i].selected = true;
					}
				}
			}
		} else {
			for(j = 0; i < val.length; j++){
				for(i = 0; i < obj.options.length; i++ ) {
					if(val[j] == obj.options[i].text) {
						obj.options[i].selected = true;
					}
				}
			}
		}
		return;
	}
	for( i = 0; i < obj.options.length; i++ ) {
		if( val == obj.options[i].text ) {
			obj.options[i].selected = true;
			return;
		}
	}
	
};

FormUtils.emptySelect = function( obj, rowsToKeep ) {
	if( "undefined" == typeof( rowsToKeep ) ) {
		var rowsToKeep = 0;
	}
	for( var i = obj.options.length-1; i >= rowsToKeep; i-- ) {
		obj.options[i] = null;
	}
};

FormUtils.removeSelectOptionByValue = function( obj, val ) {
	for( var i = obj.options.length-1; i >= 0; i-- ) {
		if( obj.options[i].value == val ) {
			obj.options[i] = null;
		}
	}
};

FormUtils.addSelectOption = function( obj, val, text ) {
	var opt = new Option( text, val );
	obj.options[obj.options.length] = opt;
};

FormUtils.removeSelectOptionsByValues = function( obj, vals ) {
	var j, found;
	for( var i = obj.options.length-1; i >= 0; i-- ) {
		found = false;
		for( j = 0; j < vals.length; j++ ) {
			if( obj.options[i].value == vals[j] ) {
				found = true;
				break;
			}
		}
		if( found ) {
			obj.options[i] = null;
		}
	}
};

FormUtils.validateNotEmptyField = function( obj, msg, nofocus ) {
	if( "" == obj.value.trim() ) {
		if( "undefined" == typeof(nofocus) || null == nofocus || !nofocus) {
			obj.focus();
		}
		if( "undefined" != typeof(msg) && null != msg ) {
			alert(msg);
		}
		return false;
	}
	return true;
};

FormUtils.validateMinimumSizeNotEmptyField = function( obj, minlen, msg, nofocus ) {
	if( obj.value.trim().length < minlen ) {
		if( "undefined" == typeof(nofocus) || null == nofocus || !nofocus) {
			obj.focus();
		}
		alert(msg);
		return false;
	}
	return true;
};

FormUtils.populateSelectControlWithMap = function( selObj, map ) {
	if( "undefined" == typeof(map) || null == map ) {
		return;
	}
	var opt;
	for( var i = 0; i < map.keys.length; i++ ) {
		opt = new Option( map.values[i], map.keys[i] );
		selObj.options[selObj.options.length] = opt;
	}
};

FormUtils.populateSelectControlWithObjectArray = function( selObj, oarr, valRef, txtRef ) {
	if( "undefined" == typeof(oarr) || null == oarr ) {
		return;
	}
	var opt;
	for( var i = 0; i < oarr.length; i++ ) {
		opt = new Option( oarr[i][txtRef], oarr[i][valRef] );
		selObj.options[selObj.options.length] = opt;
	}
};


FormUtils.populateSelectControlWithArray = function( selObj, arr ) {
	if( "undefined" == typeof(arr) || null == arr ) {
		return;
	}
	var opt;
	for( var i = 0; i < arr.length; i++ ) {
		opt = new Option( arr[i], i );
		selObj.options[selObj.options.length] = opt;
	}
};


FormUtils.populateSelectControlWithAssociativeArray = function( selObj, arr ) {
	if( "undefined" == typeof(arr) || null == arr ) {
		return;
	}
	var opt;
	for( var key in arr ) {
		opt = new Option( arr[key], key );
		selObj.options[selObj.options.length] = opt;
	}
};


FormUtils.populateSelectControlWithArrayValuesAsText = function( selObj, arr ) {
	if( "undefined" == typeof(arr) || null == arr ) {
		return;
	}
	var opt;
	for( var i = 0; i < arr.length; i++ ) {
		opt = new Option( arr[i], arr[i] );
		selObj.options[selObj.options.length] = opt;
	}
};