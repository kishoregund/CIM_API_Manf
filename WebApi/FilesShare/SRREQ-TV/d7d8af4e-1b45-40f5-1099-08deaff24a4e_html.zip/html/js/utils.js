String.prototype.lTrim = function(){
	return this.replace( /^\s+/g, "" );
};
String.prototype.rTrim = function(){
	return this.replace( /\s+$/g, "" );
};
String.prototype.trim = function(){
	return this.lTrim().rTrim();
};
String.prototype.equalsIgnoreCase = function(that){
	return this.toUpperCase() ==  that.toUpperCase();
};

//pads left
String.prototype.lpad = function(padString, length) {
	var str = this;
    while (str.length < length)
        str = padString + str;
    return str;
};
 
//pads right
String.prototype.rpad = function(padString, length) {
	var str = this;
    while (str.length < length)
        str = str + padString;
    return str;
};

String.prototype.capitalize = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
}

String.prototype.endsWith = function(suffix) {
    return this.indexOf(suffix, this.length - suffix.length) !== -1;
};

function removePunctuationAndWhiteSpaces(str) {
	return str.replace( /[.,\/#!$%\^&\*;:{}=\-_`~()\s]/g, "" );
}

function loadJS( src, cb ) {
	var fileref = document.createElement('script');
	if( isNotNullOrUndefined( cb ) ) {
		fileref.onload = cb;
	}
    fileref.async = 'true';
    fileref.setAttribute("type","text/javascript");
    fileref.setAttribute("src", src);
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore( fileref, s );
    
}

function deepEquals( obj1, obj2 ) {
	if( null == obj1 && null == obj2 ) {
		return true;
	} else if( null == obj1 ) {
		return false;
	} else if( null == obj2 ) {
		return false;
	}
	if( typeof(obj1) != typeof(obj2) ) {
		return false;
	} else if( typeof(obj1) == 'object' && typeof(obj2) == 'object' ) {
		if ( obj1.constructor === Array && obj1.constructor === Array ) {
			if( obj1.length == obj2.length ) {
				for( var i = 0; i < obj1.length; i++ ) {
					if( !deepEquals( obj1[i], obj2[i] ) ) {
						return false;
					}
				}
				return true;
			} else {
				return false;
			}
		} else {
			for( var key in obj1 ) {
				if( !deepEquals( obj1[key], obj2[key] ) ) {
					return false;
				}
			}
			return true;
		}
	} else {
		return obj1 == obj2;
	}
}

function openUrlInNewTab(url) {
	var win = window.open(url, '_blank');
	win.focus();
}

function getUrlContent(surl, urlCache) {
	if( "undefined" != typeof(urlCache) && null != urlCache ) {
		var content = urlCache.get(surl);
		if( null != content ) {
			return content;
		}
	}
	var httpObj = getNewXMLHttpRequest();
	httpObj.open("GET", surl, false);
	httpObj.send(null);
	if( "undefined" != typeof(urlCache) && null != urlCache ) {
		urlCache.put( surl, httpObj.responseText );
	}
	return httpObj.responseText;
}

function getNewXMLHttpRequest() {
	var httpObj = null;
	try {
		httpObj = new XMLHttpRequest();
	} catch (e) {
		try {
			httpObj = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e2) {
			httpObj = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	return httpObj;
}

function includeUrl(strUrl) {
	document.write(getUrlContent(strUrl));
}

function deactivateEvent(e) {
	if(window.event){
		window.event.returnValue = false;
	} else {
		e.preventDefault();
	}
}

function fakeClick(event, anchorObj) {
  if (anchorObj.click) {
    anchorObj.click()
  } else if(document.createEvent) {
    if(event.target !== anchorObj) {
      var evt = document.createEvent("MouseEvents"); 
      evt.initMouseEvent("click", true, true, window, 
          0, 0, 0, 0, 0, false, false, false, false, 0, null); 
      var allowDefault = anchorObj.dispatchEvent(evt);
      // you can check allowDefault for false to see if
      // any handler called evt.preventDefault().
      // Firefox will *not* redirect to anchorObj.href
      // for you. However every other browser will.
    }
  }
}

function equalsAny( val ) {
	for( var i = 1; i < arguments.length; i++ ) {
		if( val == arguments[i] ) {
			return true;
		}
	}
	return false;
}

function removeTableRows( objTable, firstRowsToKeep ) {
	if( "undefined" == typeof(firstRowsToKeep) ) {
		var firstRowsToKeep = 0;
	}
	for( var i = objTable.rows.length-1; i >= firstRowsToKeep; i-- ) {
		objTable.deleteRow(i);
	}
}

function htmlSelectionAttributeConditionCheck(obj, attrCond) {
	if("undefined" == typeof(attrCond) || null == attrCond ) return true;
	var attr,attrValue;
	var arr = attrCond.split(";");
	for(var i = 0; i < arr.length; i++) {
		attr = arr[i].split("=");
		attrValue = eval("obj."+attr[0]);
		if( attrValue != attr[1] ) {
			return false;
		}
	}
	return true;
}

function getAncestorHtmlElement(objChild,ancTagName,attrCond) {
	
	if( null == objChild ) {
		return null;
	}

	for(var parentObj = objChild.parentNode;
		parentObj.tagName.toUpperCase() != "BODY";
		parentObj = parentObj.parentNode
	) {
		if(
			parentObj.tagName.toUpperCase() == ancTagName.toUpperCase() &&
			htmlSelectionAttributeConditionCheck(parentObj, attrCond)
		) {
			return parentObj;
		}
	}
	
	return null;
}

function showURLInModelessDialog(url, W, H) {
	var left = (window.screen.width-W)/2;
	var top = (window.screen.height-H)/2;
	var sFeat = null;
	if(window.showModelessDialog) {
		sFeat = "dialogHeight:"+H+"px;dialogWidth:"+W+"px;status:off;scroll:yes;resizable:yes";
		return showModelessDialog(url,null,sFeat);
	} else {
		sFeat = "height="+H+"px,width="+W+"px,left="+left+"px,top="+top+"px,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,modal=no";
		return window.open(url,null,sFeat);
	}
}

function showURLInNewWindow( url, W, H, cb ) {
	var left = (window.screen.width-W)/2;
	var top = (window.screen.height-H)/2;
	var sFeat = "height="+H+"px,width="+W+"px,left="+left+"px,top="+top+"px,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,modal=no";
	var wnd = window.open( url, null, sFeat );
	if( isNotNullOrUndefined( cb ) ) {
		cb( wnd );
	}
	return wnd;
}

function cutStringAtWordBreak( string, len ) {
	if( isNullOrUndefined(string) ) {
		return 'NULL';
	}
	if( null == string || string.length <= len ) {
		return string;
	}
	var cutat= string.lastIndexOf( ' ', len );
	if( cutat != -1 ) {
		string = string.substring( 0, cutat ) + '...';
	}
	return string;
}

function cutString( string, len, nodots ) {
	if( isNullOrUndefined(string) ) {
		return 'NULL';
	}
	if( string.length <= len ) {
		return string;
	}
	string = string.substring( 0, len );
	if( 'undefined' == typeof( nodots ) || null==nodots || false===nodots ) {
		string += '...';
	}
	
	return string;
}

function isNullOrUndefined(x) {
	return ('undefined'==typeof(x) || null == x );
}

function isNotNullOrUndefined(x) {
	return ('undefined' != typeof(x) && null != x );
}

function isObjPathNullOrUndefined() {
	if( isNullOrUndefined( arguments[0] ) ) {
		return true;
	}
	for( var i = 1; i < arguments.length; i++ ) {
		if( isNullOrUndefined( ObjRefUtils.get(arguments[0],arguments[i]) ) ) {
			return true;
		}
	}
	return false;
	
}

function parseDateFromValue( val ) {
	var dt;
    if( val instanceof Date ) {
    	return val;
    } else if( "number" == typeof(val) ) {
		dt = new Date(val);
	} else {
		dt = Date.parse(val);
	}
	return dt;
}

function fmtDateNoTime(val) {
	return fmtDate( val, "MM/dd/yyyy");
}

function fmtDate( val, fmt ) {
	var dt = parseDateFromValue( val );
	if( null == dt ) {
		return '';
	}
	return dt.toString( fmt );
}

function fmtDateWithMinutes(val) {
	return fmtDate( val, "MM/dd/yyyy hh:mm");
}

function fmtDateWithSeconds(val) {
	return fmtDate( val, "MM/dd/yyyy hh:mm:ss");
}

function fmtFloat2Decimals(val) {
	return val.toFixed(2);
}

function fmtFloat4Decimals(val) {
	return val.toFixed(4);
}

function fmtFloat6Decimals(val) {
	return val.toFixed(6);
}

function defaultValue( val, def ) {
	if( "undefined" == typeof(val) || null == val ) {
		return def;
	}
	return val;
}

function defaultString( val, def ) {
	if( "undefined" == typeof(val) || null == val ) {
		if( "undefined" == typeof(def) || null == def ) {
			return '';
		} else {
			return def;
		}
		
	}
	return val;
}

function defaultStringToNullIfEmpty( val, dotrim ) {
	if("undefined" == typeof(val) || null == val || "" == val ) {
		return null;
	}
	if( 'undefined' != typeof(dotrim) && true === dotrim && val.constructor === String) {
		return val.trim();
	}
	return val;
}

function disableEnterKey(e) {
     var key;     
     if( window.event ) {
          key = window.event.keyCode; //IE
     } else {
          key = e.which; //firefox
	}   

     return (key != 13);
}

function equalsAny( first ) {
	if( 'undefined'==typeof(first) ) return false;
	for(var i = 1; i < arguments.length; i++ ) {
		if( first === arguments[i] ) {
			return true;
		}
	}
	return false;
}

var UUID = 0;
function getUUID() {
	return ++UUID;
}


var ObjRefUtils = {
	'set': function( obj, fieldNameChain, value ) {
		var arr = fieldNameChain.split(".");
		var inter = obj;
		var atoks, vidx;
		for( var i = 0; i < arr.length; i++ ) {
			atoks = arr[i].split("[");
			if( 2 == atoks.length ) {
				vidx = atoks[1].substr( 0, atoks[1].length-1 );
				//console.log(atoks[0]+"."+vidx);
			}
			if( i == arr.length-1 ) {
				if( 2 == atoks.length ) {
					inter[atoks[0]][vidx] = value;
				} else {
					inter[arr[i]] = value;
				}
				break;
			}
			if( 2 == atoks.length ) {
				if( "undefined" == typeof( inter[atoks[0]] ) || null == inter[atoks[0]] ) {
					if( null == value ) {
						break;
					}
					inter[atoks[0]] = [];
				}
				if( "undefined" == typeof( inter[atoks[0]][vidx] ) || null == inter[atoks[0]][vidx] ) {
					if( null == value ) {
						break;
					}
					inter[atoks[0]][vidx] = {};
				}
				inter = inter[atoks[0]][vidx];
			} else {
				if( "undefined" == typeof( inter[arr[i]] ) || null == inter[arr[i]] ) {
					if( null == value ) {
						break;
					}
					inter[arr[i]] = {};
				}
				inter = inter[arr[i]];
			}
		}
	},
	'get': function( obj, fieldNameChain ) {
		var arr = fieldNameChain.split(".");
		var inter = obj;
		var atoks, vidx;
		for( var i = 0; i < arr.length; i++ ) {
			atoks = arr[i].split("[");
			if( 2 == atoks.length ) {
				vidx = atoks[1].substr( 0, atoks[1].length-1 );
			}
			if( i == arr.length-1 ) {
				if( 2 == atoks.length ) {
					return inter[atoks[0]][vidx];
				} else {
					return inter[arr[i]];
				}
			}
			if( 2 == atoks.length ) {
				if( "undefined" == typeof( inter[atoks[0]] ) || null == inter[atoks[0]] ) {
					return undefined;
				}
				if( "undefined" == typeof( inter[atoks[0]][vidx] ) || null == inter[atoks[0]][vidx] ) {
					return undefined;
				}
				inter = inter[atoks[0]][vidx];
			} else {
				if( "undefined" == typeof( inter[arr[i]] ) || null == inter[arr[i]] ) {
					return undefined;
				}
				inter = inter[arr[i]];
			}
		}
	},
	'inc': function( obj, field ){
		if( 'undefined' == typeof( obj[field] ) || null == obj[field] ) {
			obj[field] = 1;
			return;
		}
		obj[field]++;
	},
	'addItemToArrayField': function( obj, field, item ){
		if( 'undefined' == typeof( obj[field] ) || null == obj[field] ) {
			obj[field] = [item];
			return;
		}
		obj[field].push(item);
	},
	'removeItemFromArrayField': function( obj, field, item, judgeField ){
		if( 'undefined' == typeof( obj[field] ) || null == obj[field] ) {
			return;
		}
		var pos = -1;
		for( var i = 0; i < obj[field].length; i++ ) {
			if( isNullOrUndefined(judgeField) ) {
				if( item == obj[field][i] ) {
					pos = i;
					break;
				}
			} else {
				if( item[judgeField] == obj[field][i][judgeField] ) {
					pos = i;
					break;
				}
			}
		}
		if( pos > -1 ) {
			obj[field].splice(pos,1);
		}
	},
	'divable': function(fieldNameChain) {
		return fieldNameChain.replace( ".", "_" );
	}
};

function appendParamsToUrl(url) {
	var quest = false;
	for( var i = 1; i < arguments.length; i+=2 ) {
		if( ( i+1 ) < arguments.length ) {
			if( null != arguments[i+1] ) {
				if( quest ) {
					url += '&';
				} else {
					url += '?';
					quest = true;
				}
				url += arguments[i];
				url += "=" + arguments[i+1];
			}
		} else {
			if( quest ) {
				url += '&';
			} else {
				url += '?';
				quest = true;
			}
			url += arguments[i];
		}
	}
	return url;
}

function printStackTrace() {
	  var e = new Error('dummy');
	  var stack = e.stack.replace(/^[^\(]+?[\n$]/gm, '')
	      .replace(/^\s+at\s+/gm, '')
	      .replace(/^Object.<anonymous>\s*\(/gm, '{anonymous}()@')
	      .split('\n');
	  console.log(stack);	
}

function printObject(o) {
  var out = '';
  for (var p in o) {
    out += p + ': ' + o[p] + '\n';
  }
  console.log(out);
}

function simpleAjaxGet( surl, successHandler, errrorHandler ) {
	$.ajax({
		'url' : surl,
		'type' : "GET",
		'success' : function( content ) {
			successHandler (content );
		},
		'error' : function( content, textStatus ) {
			if( 'undefined' != typeof(errorHandler) && null != errorHandler ) {
				errorHandler( content );
			} else {
				console.log('Error!' + JSON.stringify(textStatus) + "\n"
					+ JSON.stringify(content));
			}
		}
	});
}

function humanFileSize(bytes, si) {
    var thresh = si ? 1000 : 1024;
    if(Math.abs(bytes) < thresh) {
        return bytes + ' b';
    }
    var units = ['kb','mb','gb','tb','pb','eb','zb','yb'];
    var u = -1;
    do {
        bytes /= thresh;
        ++u;
    } while(Math.abs(bytes) >= thresh && u < units.length - 1);
    return bytes.toFixed(1)+' '+units[u];
}

function mergeIntoFirstByAddingMissingProperties( dest, src, overwrite ) {
	for( var key in src ) {
		if( key in dest ) {
			if( typeof( dest[key]) == 'object' ) {
				mergeIntoFirstByAddingMissingProperties( dest[key], src[key], overwrite );
			} else if ( true === overwrite ) {
				dest[key] = src[key];
			}
		} else {
			dest[key] = src[key];
		}
	}
}


function simpleHttpMethodJsonFromServer( method, surl, useMessageInSuccess, successHandler, errorHandler ) {
	var m;
	if( isNullOrUndefined(method) ) {
		m = "GET";
	} else {
		m = method;
	}
	$.ajax({
		'url' : surl,
		'headers' : { "Accept" : "application/json" },
		'dataType' : "json",
		'type' : m,
		'success' : function( content ) {
			if( content.success ) {
				if( 'undefined' != typeof( successHandler ) && null != successHandler ) {
					if( true === useMessageInSuccess ) {
						successHandler( content.message );
					} else {
						successHandler( content.payload );
					}
				} else {
					alert( content.message );
				}
			} else {
				if( 'undefined' != typeof( errorHandler ) && null != errorHandler ) {
					errorHandler( content.message );
				} else {
					alert(content.message);
				}
			}
		},
		'error' : function( content, textStatus ) {
			if( 'undefined' != typeof(errorHandler) && null != errorHandler ) {
				errorHandler( content );
			} else {
				alert('Error!' + JSON.stringify(textStatus) + "\n"
					+ JSON.stringify(content));
			}
		}
	});
	
}


function escapeHtml(unsafe) {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}


